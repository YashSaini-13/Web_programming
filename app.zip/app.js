// Import required modules for the application
const express = require("express"); 
const crypt = require("crypto");
const app = express(); 
const session = require("express-session");
const cookieParser = require("cookie-parser");
const mysql = require("mysql2");

// Retrieve MySQL password from environment variable
const pass = process.env.ROOTPASS; 

// Setup the MySQL database connection
const conn = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: pass,
    database: "students",
    port: 3306
});

// Middleware configuration for parsing request bodies and cookies
app.use(express.urlencoded({ extended: true })); 
app.use(express.static("public")); // Serves static files (like HTML and CSS) from the public directory
app.use(cookieParser());

// Configure session middleware to handle secure user sessions
app.use(session({
  secret: process.env.SESSION_SECRET || 'verysecretkey', // Used to sign the session ID cookie
  resave: false,                    // Prevents resaving unchanged sessions
  saveUninitialized: false,         // Prevents storing empty, uninitialized sessions
  cookie: { 
    maxAge: 60000 * 60,             // Cookie expiry in milliseconds (1 hour)
    httpOnly: true,                 // Protects against XSS attacks
    secure: false                   // Set to true if using HTTPS
  }
}));

// Password hashing configuration parameters
const hashRounds = 100;
const hashLength = 64;
const salt = "Kitten";

// Establish connection to the MySQL database
conn.connect(function(err) {
	if(err)
		console.log("Couldnt connect to MySQL", err);
	else
		console.log("Database connection established");
});

// Route handle for user registration/signup
app.post("/signup", function(req, res) {
	let plainPass = req.body.password; 
	let username = req.body.userName;
	let fname = req.body.fname;
	let lname = req.body.lname;
	let gpa = Number(req.body.gpa);
	
	// Hash the password using PBKDF2 before storing it in the database
	hashedPass = crypt.pbkdf2Sync(plainPass, salt, hashRounds, hashLength, 'sha512').toString(`hex`);
	let sql = "insert into students (fname,lname,gpa,user_id,password,salt) values (?,?,?,?,?,?)";
	
	conn.query(sql, [fname, lname, gpa, username, hashedPass, salt], function(err, result) {
		if (err)
			console.log("There was an error inserting a student", err);
		else
			res.send("<p> You have inserted " + fname + " " + lname + " " + "into " + result.affectedRows + ' row <a href="login.html">Login </a> here </p>');
	});
});

// Route handle for user profile page (protected by session check)
app.get("/profile", function(req, res) {
	// Check if session user exists; if not, deny access
	if (!req.session.user)
		res.send('You are not logged in. Please <a href="login.html">Login here</a>.');
	else {
		res.send(`Hi ${req.session.user.user_id}. Your gpa is ${req.session.user.gpa}. <br><a href="/logout">Logout</a>`);
	}
});

// Route handle for user logout
app.get("/logout", function(req, res) {
	// Destroy the session to clear authentication state
	req.session.destroy((err) => {
		if (err) res.send("Error logging out");
		else res.send('Logged out successfully! <a href="login.html">Login Here</a>');
	});
});

// Route handle for user login processing
app.post("/login", function(req, res) {
	let plainPass = req.body.password; 
	let username = req.body.username;
	let saltVal = "Kitten";
	
	// Hash the incoming password with the salt to match the database record
	const pass = crypt.pbkdf2Sync(plainPass, saltVal, hashRounds, hashLength, 'sha512').toString(`hex`);
	let sql = 'select * from students where user_id=? and password = ?';
	
	conn.query(sql, [username, pass], function(err, result) {
		if (err)
			res.send(err);
		else {
			if (result.length === 0) {
				console.log('results of the query', result);
				res.send('<p>Your password or username are incorrect<br> <a href="login.html">Login </a> here </p>');	
			}
			else {
				// Store user details in the session upon successful authentication
				req.session.user = { user_id: username, gpa: result[0].gpa };
				
				// Redirect the user to the about page after a successful login
				res.redirect('/about.html');
			}
		} 
	});
});

// Start the server on port 3000
app.listen(3000, () => {
    console.log("Server is running on port 3000");
});